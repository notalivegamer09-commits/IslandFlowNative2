# Build the APK using only your Android phone (GitHub Actions)

This project is Android source code, not an APK. The included GitHub Actions workflow builds the APK in GitHub's cloud; no computer or Android Studio is required.

1. In your phone browser, sign in to https://github.com/ or create a free account.
2. Extract this ZIP using your phone's Files app. You should see the `IslandFlowNative` folder.
3. On GitHub, create a new **public** repository named `IslandFlowNative` (public repositories can use GitHub-hosted Actions without consuming private-repository minutes; GitHub's current limits and policies may change).
4. Open the new repository, choose **Add file → Upload files**, and upload the *contents* of the `IslandFlowNative` folder, including the hidden `.github` folder and its `workflows/build-apk.yml` file. The repository root must contain `settings.gradle`, `build.gradle`, `app/`, and `.github/`.
5. Commit the uploaded files to the `main` branch.
6. Open the repository's **Actions** tab. If GitHub asks, enable Actions. Select **Build IslandFlow APK** and tap **Run workflow** → **Run workflow**.
7. Wait for the run to finish with a green check. Open that run, scroll to **Artifacts**, and download `IslandFlow-debug-APK`.
8. Extract the downloaded artifact ZIP. Tap `app-debug.apk` and install it. If Android blocks it, allow your browser or file manager to install unknown apps, then retry.
9. Open IslandFlow. Enable **Display over other apps** and **Notification access** only if you want notification previews. Return to the app and tap **Start Dynamic Island**.

If uploading from a phone, make sure the `.github` folder is included. Some file pickers hide dot-folders; if it is missing, the workflow will not appear in Actions.
