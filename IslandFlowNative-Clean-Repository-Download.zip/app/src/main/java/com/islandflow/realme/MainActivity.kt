package com.islandflow.realme

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(10, 11, 18))
        }
        val title = TextView(this).apply {
            text = "IslandFlow"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Dynamic Island for your Realme"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(190, 190, 210))
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 22)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(actionButton("1. Allow display over other apps") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        root.addView(actionButton("2. Enable notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(actionButton("3. Start Dynamic Island") {
            if (!Settings.canDrawOverlays(this)) {
                status.text = "First allow display over other apps."
            } else {
                startForegroundService(Intent(this, IslandOverlayService::class.java))
                status.text = "IslandFlow is running. Return to your home screen."
            }
        })
        root.addView(actionButton("Stop Dynamic Island") {
            stopService(Intent(this, IslandOverlayService::class.java))
            status.text = "IslandFlow stopped."
        })
        val note = TextView(this).apply {
            text = "Notification access is optional but needed for real notification previews and media-session controls. Android will show a separate permission screen."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 26, 0, 0)
        }
        root.addView(note)
        setContentView(root)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        val overlay = Settings.canDrawOverlays(this)
        status.text = "Overlay permission: ${if (overlay) "Allowed" else "Not allowed"}\nNotification access: ${if (IslandNotificationListener.isEnabled(this)) "Enabled" else "Not enabled"}"
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 7, 0, 7)
            layoutParams = params
        }
}
